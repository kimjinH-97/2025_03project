package com.project03.repository.kakaoapi;

import com.project03.entity.Route;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RouteRepository extends JpaRepository<Route, Long>
{
}
